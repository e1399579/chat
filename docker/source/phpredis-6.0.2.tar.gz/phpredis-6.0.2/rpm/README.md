You can find and up to date version of this RPM builder here :

https://src.fedoraproject.org/rpms/php-pecl-redis5/tree/master
