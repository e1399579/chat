# API Documentation

```bash
curl -O https://doctum.long-term.support/releases/latest/doctum.phar
chmod +x doctum.phar

./doctum.phar update doctum-config.php
```